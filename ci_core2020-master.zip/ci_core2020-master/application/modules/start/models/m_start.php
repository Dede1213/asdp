<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_start
    parent::__construct();
    //Codeigniter : Write Less Do More
  }

}
